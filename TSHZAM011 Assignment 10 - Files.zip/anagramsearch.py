# Program that searches a file for anagrams of a given word, printing the results in alphabetical order
# Zamashengu Tshabalala
# TSHZAM011
# 30 April 2024

try:
  print("***** Anagram Finder *****")
  file = open("EnglishWords.txt","r")
  words = file.read()
  new = words[words.find("START") + 6:]
  wordslist = new.split("\n")
  file.close()
  input1 = input("Enter a word:\n").lower()
  array = []
  # new_input = input1.lower() 
  for word in wordslist:
    #new_word = word.lower()  
    if sorted(word) == sorted(input1):
      array.append(word)
  
  if (len(array) == 0) or  ((len(array) == 1) and (input1 in array)):
    print("Sorry, anagrams of " + "'" + input1+ "'"+ " could not be found.")
  else:
    if input1 in array:
      array.remove(input1)
    array.sort()
    print(array)
    
  
except IOError as erText:
  print("Sorry, could not find file 'EnglishWords.txt'.")
#  print("Some other error occurred")
finally:
  print(" ")

    
