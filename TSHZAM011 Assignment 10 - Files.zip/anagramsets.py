# Program to t asks the user to enter a word length and a filename
# Zamashengu Tshabalala
# TSHZAM011
# 3 May 2024

try:
    print("***** Anagram Set Search *****")
    length = input("Enter word length:\n")
    print("Searching...")
    filename = input("Enter file name:\n")
    print("Writing results...")
    myfile = open("EnglishWords.txt","r")
    words = myfile.read()
    new = words[words.find("START") + 6:]
    wordslist = new.split("\n")
    myfile.close()
    same_length = []
    for word in wordslist:
        if len(word) == int(length):
            same_length.append(word)
    same_length.sort()
    File = open(filename, "w")
    all_list = []
    for each in range(len(same_length)):
        each_word = []
        for index in range(each,len(same_length)):
            if sorted(same_length[each]) == sorted(same_length[index]):
                each_word.append(same_length[index])
        if len(each_word)>= 2:
            all_list.append(each_word)
    for x in range(len(all_list)-1):
        for each1 in range(x,len(all_list)-1):
            if all_list[x][0] == all_list[each1][0]:
                del all_list[x]
    for result in all_list:
        print(result,file = File) 
    File.close()
    print(len(all_list))
    
except IOError as erText:
    print("Sorry, could not find file 'EnglishWords.txt'.")

finally:
    print(" ")
  
    