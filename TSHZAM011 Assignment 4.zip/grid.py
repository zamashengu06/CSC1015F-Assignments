# Program to grid og numbers in a sequence
# Zamashengu Tshabalala
# TSHZAM011
# 9 March 2024

num = eval(input("Enter a number between -6 and 2:\n"))

if num>-6 and num<2:
    seq = num
    for seq in range(num, num + 7):   
        if seq >= 0 and seq < 10:     
            print("",seq,end =" ")
        else:
            print(seq, end=" ")
    print()
                     
    for seq in range(num + 7,num+14):
        if seq >= 0 and seq < 10:
            print("",seq,end=" ")
        else:
            print(seq,end=" ") 
    print()
    
    for seq in range(num + 14,num + 21):
        if seq>= 0 and seq < 10:
            print("",seq,end=" ")
        else:
            print(seq,end=" ")
    print()
    
    for seq in range(num + 21,num + 28):
            print(seq,end=" ")
    print()
    
    for seq in range(num + 28,num + 35):
            print(seq,end=" ")
    print()  
    
    for seq in range(num + 35,num + 42):
            print(seq,end=" ")              
    
else:
    print("Invalid input! The value of 'n' should be between -6 and 2.")
           
