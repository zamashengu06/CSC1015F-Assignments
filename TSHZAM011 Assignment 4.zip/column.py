# Programm to print out every 7th number in the range n to n+41
# Zamashengu Tshabalala TSHZAM011
# 9 March 2024

num = eval(input("Enter a number between -6 and 2:\n"))

if num>-6 and num<2:
    seq = num
    for seq in range(num, num + 41,7):   
        if seq >= 0 and seq < 10:     # find way to remove space at end
            print("",seq)
        else:
            print(seq)          
else:
    print("Invalid input! The value of 'n' should be between -6 and 2.")