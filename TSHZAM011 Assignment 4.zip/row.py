# Program to print a sequence of 7 numbers starting from that number 
# Zamashengu Tshabalala
# TSHZAM011
# 9 March 2024

num = eval(input("Enter a number between -6 and 93:\n"))


if num>-6 and num<93:
    seq = num
    for seq in range(num, num + 7):   
        if seq >= 0 and seq < 10:     # find way to remove space at end
            print("",seq,end=" ")
        else:
            print(seq,end=" ",sep="") 
            
       
        
            
            
else:
    print("Invalid input! The value of 'n' should be between -6 and 93.")
    

   
   
   
