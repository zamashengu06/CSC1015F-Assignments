# Program to check the validity of time enyered by the user
# Zamashengu Tshabalala
# TSHZAM011
# 26 February 2024

hour = eval(input("\nEnter the hours: "))
minute = eval(input("\nEnter the minutes: "))
second = eval(input("\nEnter the seconds: "))

if hour >= 0 and hour <= 23 and minute >= 0 and minute <= 59 and second >= 0 and second <= 59:
    print("\nYour time is valid.")
else:
    print("\nYour time is invalid.")


    
