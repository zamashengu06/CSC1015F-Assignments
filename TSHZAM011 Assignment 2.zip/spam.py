# Program to generate a spam message based on the user's info
# Zamashengu Tshabalala
# TSHZAM011
# 25 February 2024

First_name = input("\nEnter first name: ")
Last_name = input("\nEnter last name: ")
Money = eval(input("\nEnter sum of money in USD: "))
Country = input("\nEnter country name: ")
money_paid = 0.3 * Money    # to calculate the amount of money the user will have to pay 
print("")
print("\nDearest",First_name)
print("It is with a heavy heart that I inform you of the death of my father,",end="")
print("\nGeneral Fayk",Last_name,end ="")
print(", your long lost relative from Mapsfostol.",end="")
print("\nMy father left the sum of",Money,end="")
print("USD for us, your distant cousins.",end="")
print("\nUnfortunately, we cannot access the money as it is in a bank in", Country, end= ".")
print("\nI desperately need your assistance to access this money.")
print("I will even pay you generously, 30% of the amount -",money_paid,end="")
print("USD,",end ="")
print("\nfor your help.  Please get in touch with me at this email address asap.")

print("Yours sincerely")
print("Frank",Last_name)