# Program to determin whether a year is a leap year or not
# Zamashengu Tshabalala
# TSHZAM011
# 25 February 2024

year = int(input("\nEnter a year: "))



if year%400 != 0 and year%100 == 0 and year%4 == 0:
   print("\n",end="")
   print(year,"is not a leap year.")
   
elif year% 4 != 0:
      print("\n",end="")
      print(year,"is not a leap year.")
            
else: 
   print("\n",end="")
   print(year,"is a leap year.")
    
    
           

