# Program to extract uceful data from a raw data stream 
# Zamashengu Tshabalala
# TSHZAM011
# 31 March 2024

def location(block):
    s_loc1 = block.find(" ")
    s_loc = block.find(" ",s_loc1 + 1)
    e_loc = block.find("END") - 1
    loc = block[s_loc:e_loc]
    location = ""
    for c in loc:
        location = c + location  
        location = location.title()
    return location
  
def temperature(block):
    s_temp = block.find("BEGIN") + 5
    e_temp = block.find("_")
    temp = block[s_temp:e_temp]
    return eval(temp)
    
def x_coordinate(block):
    s_xcoor = block.find(":") + 1
    e_xcoor = block.find(",")
    x_coor = block[s_xcoor:e_xcoor]
    return x_coor

def y_coordinate(block):
    s_ycoor = block.find(",") + 1
    e_ycoor1 = block.find(" ")
    e_ycoor = block.find(" ",e_ycoor1 + 1)   
    y_coor = block[s_ycoor:e_ycoor]
    return y_coor

def pressure(block):
    s_pres = block.find("_") + 1
    e_pres = block.find(":")
    press = block[s_pres:e_pres]
    return float(press)


def get_block(data):
    start = data.find("BEGIN")
    end = data.find("END")
    block = data[start:end+3]
    return block
 
 
def main():
    data = input('Enter the raw data:\n')
    block = get_block(data)
    print('Site information:')
    print('Location:', location(block))
    print('Coordinates:', y_coordinate(block), x_coordinate(block))
    print('Temperature: {:.2f} C'.format(temperature(block)))
    print('Pressure: {:.2f} hPa'.format(pressure(block)))

if __name__=='__main__':
    main()
