# Program to calculate how many syllables a word contains.
# Zamashengu Tshabalala
# TSHZAM011
# 31 March 2024

def count_syllables(word):
    count = 0
    vowels = ["a","e","i","o","u","y"]
    word2 = word.lower()
    if word[0] in vowels:
        count += 1
    for letter in range(1, len(word2)):      # Checking for any double vowels
        if word2[letter] in vowels and word2[letter -1] not in vowels :
            count += 1
    if word2[-1] == "e" and word2[-2] not in vowels:       # To determine whether the last letter is e
        count -= 1
    if count == 0:
        count += 1
    return count
    
def main():
    word = ""
    while word != "q" :
        word = input('Enter a word (or \'q\' to quit):\n')
        if count_syllables(word) == 1 and word != "q":
                print("The word " + "'" + word +  "'"+ " has "  + str(count_syllables(word)) + " syllable.\n")
        elif count_syllables(word)> 1 and word != "q":
                print("The word " + "'" + word +  "'"+ " has "  + str(count_syllables(word)) + " syllables.\n")

# Do not modify.
if __name__ == '__main__':
    main()

