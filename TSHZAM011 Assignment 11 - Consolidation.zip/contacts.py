# Program that creates a simple contact manager to store, process and retrieve a person’s names, contact number, and email address.
# Zamashengu Tshabalala
# TSHZAM011
# 6 May 2024

def path_exists(file_path):
    try:
        open(file_path,"r")
        return True
    except IOError as erText:
        return False
        
def create_file(file_path):  # to create the file if it does not exist
    myFile = open(file_path, "w")
    myFile.close()
    print("Contacts file " + "'" + file_path+ "'" + " created.")
        
def add_contact(file_path,name,phone,email):
    myFile = open(file_path, "a")
    if search(file_path,name,phone,email):
        return "Contact already exists."
    else:
        print(name +"," + phone+ "," + email, file = myFile)
        return "Contact added successfully."
    myFile.close() 

    
def search(file_path,name,phone,email): # search through file to check if the contacts exists
    myfile = open(file_path,"r")
    compare = [name,phone,email]
    new =  read_contacts(file_path)
    myfile.close()
    for i in new:
        if i == compare:
            return True
    return False
    
def custom_sort(contacts):
    list1 = sorted(contacts)
    return list1


def find_name(file_path, target): # finds the name if the query is a name
    array = read_contacts(file_path)
    found = []
    for i in array:
        if target == i[0]:
            found.append(i)
        else:
            name_surname = i[0].split(" ") # look for the name and surname individually
            for find in name_surname:
                if target in find: 
                    found.append(i)   
    return found
    
        
def find_number(file_path,target): # to find the number if the query is a number
    array = read_contacts(file_path)
    found = []
    for i in array:
        if target in i[1]:
            found.append(i)
    return found
        
def find_email(file_path,target): # to find the number if the query given is an email
    array = read_contacts(file_path)
    found = []
    for i in array:
        if target in i[2]:
            found.append(i)
    return found 

def search_contact(file_path, query):
    myFile = open(file_path, "r")
    search = sorted(read_contacts(file_path))
    myFile.close()
    if query == "*":
        lists = sorted(read_contacts(file_path))    
    elif not query.isdigit():
        lists = find_name(file_path,query)
        if len(lists) == 0:
            return "\nNo contact found.\n"
    elif query.isdigit():
        lists = find_number(file_path,query)
        if len(lists) == 0:
            return "\nNo contact found.\n"
    else:
        lists = find_email(file_path,query)
        if len(lists) == 0:
            return "\nNo contact found.\n"       
    if len(lists)>=1:
        print("\nFound contact(s):")
        print("=" * 60)
        print("| " + "{:<21}".format("Name") +"| " +"{:<16}".format("Phone")+"| " + "{:<26}".format("Email") +"|")
        print("=" * 60)
        for i in range(len(lists)):
            print("| " + "{:<21}".format(lists[i][0]) + "| "+ "{:<16}".format(lists[i][1]) +"| " + "{:<26}".format(lists[i][2]) +"|")
            print("-"*60)
    return ""
        
  
def read_contacts(file_path):
    myFile = open(file_path,"r")
    array = []
    for line in myFile:
        new = line.replace("\n","")
        new4 = new.split(",")
        array.append(new4)
    return array

def list_contacts(file_path):
    file = open(file_path,"r")
    contacts = sorted(read_contacts(file_path))
    file.close()
    print("\nList of contacts:")
    print("=" * 60)
    print("| " + "{:<21}".format("Name") +"| " +"{:<16}".format("Phone")+"| " + "{:<26}".format("Email") + "|")
    print("=" * 60)    
    for each in range(len(contacts)):
        print("| " + "{:<21}".format(contacts[each][0]) + "| "+ "{:<16}".format(contacts[each][1]) +"| " + "{:<26}".format(contacts[each][2]) +"|")
        print("-"*60)

def main():
    file_path = input("Enter the name for the contacts file:\n")+ ".txt"
    if not path_exists(file_path):
        create_file(file_path)    
    print()
    print("1. Add Contact")
    print("2. Search Contact")
    print("3. List Contacts")
    print("4. Exit")         

    choice = input("Enter your choice: ")
    while choice != "4":        
        if choice == "1":
            name =input("Enter name: ")
            phone = input("Enter phone number: ")
            email = input("Enter email: ") 
            print(add_contact(file_path,name,phone,email))
        elif choice == "2":
            query = input("Enter first name, last name, phone number, or email to search: ")
            print(search_contact(file_path,query),end='')
        elif choice == "3":
            list_contacts(file_path)
        print()
        print("1. Add Contact")
        print("2. Search Contact")
        print("3. List Contacts")
        print("4. Exit")  
        choice = input("Enter your choice: ")
    print("Exiting program.")
    
    
if __name__ =="__main__":
    main()