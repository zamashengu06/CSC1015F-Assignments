# Program to takes in a list of marks and outputs a histogram representation of the marks 
# Zamashengu Tshabalala TSHZAM011
# 14 April 2024

num = input("Enter a space-separated list of marks:\n")
list1 = num.split(" ")
first = 0
upper_2 = 0
lower_2 = 0
third = 0 
fail = 0

for x in list1:
    if int(x) < 50:
        fail += 1
    if int(x) >= 50 and int(x) < 60:
        third+=1
    if int(x) >= 60 and int(x)<70:
        lower_2 += 1
    if int(x)>= 70 and int(x)< 75:
        upper_2 +=1
    if int(x)>= 75 and int(x)<= 100:
        first += 1

print("1 |" +first * "X")
print("2+|"+upper_2 * "X")
print("2-|"+lower_2 * "X")
print("3 |"+ third * "X")
print("F |"+ fail * "X")