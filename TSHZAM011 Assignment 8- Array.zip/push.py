# Program to to repeatedly merge adjacent numbers in a grid until the number 2048 is found
# Zamashengu Tshabalala
# TSHZAM011
# 18 April 2024

import util

def push_up(grid):
    """merge grid values upwards"""
    for r in range(4):
        for c in range(4):
            if r<3:
                    if grid[r][c] == 0:
                        grid[r][c] = grid[r+1][c]
                        grid[r+1][c] = 0
                    if grid[r][c] == grid[r+1][c]:
                        grid[r+1][c] = grid[r][c]*2
                        grid[r][c] = 0
                                 
def push_down(grid):
    """merge grid values downwards"""
    for r in range(4,0):
        for c in range(4):
            if r>1:
                    if grid[r][c] == 0:
                        grid[r][c] == grid[r+1][c]
                        grid[r+1][c] = 0
                    elif grid[r][c] == grid[r+1][c]:
                        grid[r][c] = grid[r][c]*2
                        grid[r+1][c]= 0
def push_left(grid):
    """merge grid values left"""
    for r in range(4):
        for c in range(4):
            if c <3:
                if grid[r][c] == 0:
                    grid[r][c] = grid[r][c+1]
                    grid[r][c+1] = 0
                if grid[r][c] == grid[r][c+1]:
                    grid[r][c] = grid[r][c]*2
                    grid[r][c+1] = 0
                
def push_right(grid):
    """merge grid values right"""
    for r in range(4):
        for c in range(4,0):
            if c >1:
                if grid[r][c] == 0:
                    grid[r][c] == grid[r][c+1]
                    grid[r][c+1] = 0
                if grid[r][c] == grid[r][c+1]:
                    grid[r][c] = grid[r][c]*2
                    grid[r][c+1] = 0   