# Program to for manipulating 2-dimensional arrays of size 4x4
# Zamashengu Tshabalala
# TSHZAM011
# 15 April 2024

def create_grid(grid):
    """create a 4x4 array of zeroes within grid"""
    for r in range(4):
        grid.append([0]*4)
    
            
def print_grid(grid):
    """print out a 4x4 grid in 5-width columns within a box"""
    print("+--------------------+")
    for r in range(4):
        print("|",end="")
        for c in range(4):
            if grid[r][c] == 0:
                print("{0:<5}".format(" "),end="")
            else:
                print("{0:<5}".format(grid[r][c]),end="")    
        print("|")
    print("+--------------------+")
    
def check_lost(grid):
    """return True if there are no 0 values and there are no adjacent values that are equal; otherwise False""" 
    for r in range(4):
        for c in range(4):
            if grid[r][c] == 0:
                return False
            if c < 3 and r<3:
                if grid[r][c] == grid[r][c+1]:
                    return False
    
            if grid[r][c] == 0:
                return False
            if c < 3 and r <3:
                if grid[r][c] == grid[r+1][c]:
                    return False
    
    return True
    
def check_won(grid):
    """return True if a value>=32 is found in the grid; otherwise False""" 
    for r in range(4):
        for c in range(4):
            if grid[r][c] >= 32:
                return True
            
    return False
            
def copy_grid(grid):
    """return a copy of the given grid"""
    copy = []
    create_grid(copy)
    for r in range(4):
        for c in range(4):
            value = grid[r][c]
            copy[r][c] = value
    return copy
            

def grid_equal(grid1,grid2):
    """check if 2 grids are equal - return boolean value"""       
    return grid1 == grid2
