# A recursive function can be used to determine if a given pattern matches a given word.
# Zamashengu Tshabalala
# TSHZAM011
# 23 April 2024

def match(pattern,word):
    if len(pattern) == 0 and len(word) ==0:
        return True
    elif len(pattern) == 0 or len(word) == 0: 
        return False
    elif len(pattern) != len(word): # automatically False if either string is longer than the other
        return False
    elif pattern[0] == word[0] or pattern[0] == "?": # slice when they are the same
        return match(pattern[1:],word[1:])
    
    
    
    
    
    
    
    
    
    
    9
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    9