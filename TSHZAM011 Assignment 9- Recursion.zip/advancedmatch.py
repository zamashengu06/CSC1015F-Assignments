# Program that can be used to determine if a given pattern matches a given word
# Zamashengu Tshabalala
# TSHZAM011
# 23 April 2024

def match(pattern,word):
      if len(pattern) == 0 and len(word) == 0:
            return True
      if len(pattern) == 0 or len(word) == 0:
            return False
      elif pattern[0]== "*" and len(word)<2:
            return True
      elif pattern[0] == word[0] or pattern[0] == "?":
            return match(pattern[1:],word[1:])      
      elif  pattern[0]== "*": 
            if  len(pattern[:]) != 1 and  pattern[1] == "*": # check if the second letter in the pattern is "*"
                  return match(pattern[2:],word[2:])
            if len(pattern) == 0 and len(word)> len(pattern): # if the pattern is just "*" and there are still more letters in the word
                  return True
            if len(pattern[:]) != 1 and  pattern[1] == word[0]:
                  return match(pattern[1:],word)            
            if len(pattern) < len(word) + 1:
                  return match(pattern,word[1:])
            
            
