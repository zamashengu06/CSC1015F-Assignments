# Recursive program to determine a palindrome
# Zamashengu Tshabalala
# TSHZAM011
# 22 April 2024

def palindrome(word):
    if len(word) == 0: # if string is empty
        return True
    if word == " ":
        return True
        
    elif word[0] == word[-1]: #  if last letter and first letter are the same
        return palindrome(word[1:-1]) # slice to check the letters inside
    else:
        return False
    
def main():
    word = input("Enter a string:\n")  
    if palindrome(word):
        print("Palindrome!")
    else:
        print("Not a palindrome!")

if __name__ == "__main__":
    main()
    
    

