# Program find all palindromic primes between two integers N, M, supplied as input
# Zamashengu Tshabalala
# TSHZAM011
# 24 April 2024

import sys
sys.setrecursionlimit (30000)
 
def isprime(num,divide): 
# used to check if number given is a prime number
    if num == divide:
        return True
    if num % divide  == 0:
        return False
    if num % divide != 0:
        return isprime(num,divide +1)  # divide the number by each number starting from 2
    

def palindrome(number):
    num = str(number) 
    if len(num) == 0:
        return True  
    if num == " ":
        return True
        
    elif num[0] == num[-1]: # if the first letter is the same as the last, we slice to check the numbers inside
        return palindrome(num[1:-1])
    else:
        return False

def palindrome_num(start,end):
    if start == end +1:
        return 
    if  palindrome(start): # for efficiency, we check the number is a palindrome first
        if isprime(start,2):
            print(start)
    palindrome_num(start+1,end) # if False, move on the next number
        

start = int(input("Enter the starting point N:\n"))
end = int(input("Enter the ending point M:\n"))  
       
    
    
def main():
    print("The palindromic primes are:")
    palindrome_num(start,end)


if __name__ == "__main__":
    main()

    