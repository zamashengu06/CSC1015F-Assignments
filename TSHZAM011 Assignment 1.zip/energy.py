# A program that calculates energy
# Zamashengu Tshabalala 
# TSHZAM011
# 22 February 2024

mass = eval(input("Enter the value of m: "))
print("")
constant = eval(input("Enter the value of c: "))
print("")
E = mass*constant**2

print("The value of energy, E, is:",E,)


