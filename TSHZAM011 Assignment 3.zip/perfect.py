# Program to determine if the given number is a perfect number
# Zamashengu Tshabalala TSHZAM011
# 4 March 2024


n = eval(input("Enter a number:\n"))
s = n

print("The proper divisors of",n,"are:")
sum1 = 0
for x in range(1, n):
    divsor = n%x
    if divsor == 0:
        print(x,end=' ')
        sum1+= x
print()
if sum1 == s:
    print("\n",s," is a perfect number.",sep="")
else:
    print("\n",s," is not a perfect number.",sep="")






       






     
 

    
        



