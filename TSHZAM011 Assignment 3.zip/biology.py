# Program to determine the type of an animal based on the classification scheme
# Zamashengu Tshabalala TSHZAM011
# 4 March 2024

print("Welcome to the Biology Expert")
print("-----------------------------")

print("Answer the following questions by selecting from among the options.",end ="")

skele = input("\nThe skeleton is (internal/external)? " )

if skele == "external":
    print("\nType of animal: Arthropod")

else:
    fertili = input("\nThe fertilisation of eggs occurs (within the body/outside the body)? ")
    
    if fertili == "outside the body":
        types = input("\nIt lives (in water/near water)? ")
        if types == "in water":
            print("\nType of animal: Fish")
        else:
            print("\nType of animal: Amphibian")
    else:
        produced = input("\nYoung are produced by (waterproof eggs/live birth)? " )
        if produced == "live birth":
            print("\nType of animal: Mammal")
        else:
            skin = input("\nThe skin is covered by (scales/feathers)? ")
            if skin == "scales":
                print("\nType of animal: Reptile")
            else:
                print("\nType of animal: Bird")
                    
                    
                    
                    
                    
                   
