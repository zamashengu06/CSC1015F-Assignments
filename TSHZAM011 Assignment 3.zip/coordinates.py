# Program to check if a set of six numbers is a pair of GPS coordinates
# Zamashengu Tshabalala TSHZAM011
# 4 March 2024


n1 = eval(input("Enter first number:\n"))
n2 = eval(input("Enter second number:\n"))
n3 = eval(input("Enter third number:\n"))
n4 = eval(input("Enter fourth number:\n"))
n5 = eval(input("Enter fifth number:\n"))
n6 =eval(input("Enter sixth number:\n"))

if n1 <= 90 and n1>= -90 and n2>=0 and n2<=59 and n3>= 0 and n3<=59 and n4>= -180 and n4<= 180 and n5>= 0 and n5<=59 and n6>= 0 and n6<= 59:
    print("WOW! Looks like geographic coordinates!")
    

else:
    print("Hmmm ... looks like 6 random numbers.")
    
