# Doctest to Develop a set of 5 test cases that achieve statement coverage.
# Zamashengu Tshabalala 
# TSHZAM011
# 9 April 2024

"""
>>> import palindrome
>>> palindrome.is_palindrome(' ')
True
>>> palindrome.is_palindrome('sands')
False
>>> palindrome.is_palindrome('racecar')
True
>>> palindrome.is_palindrome("A CAR")
False
>>> palindrome.is_palindrome("2  2")
True

"""

import doctest
doctest.testmod(verbose = True)