#Doctest to develop a set of 6 test cases that achieve statement coverage.
# Zamashengu Tshabalala
# TSHZAM011
# 11 April 2024

#  if colon<1:
# if len(hours)>2 or len(hours)<1 or not hours.isdigit():
# if len(hours)==2 and int(hours[0])==0:
#  if not suffix==' a.m.' and not suffix==' p.m.':
# if not len(minutes)==2 or not minutes.isdigit():
# 



"""

>>> import timeutil
>>> timeutil.validate(":02 a.m.")  
False
>>> timeutil.validate("111:20 p.m.")
False
>>> timeutil.validate("01:40 a.m.")
False
>>> timeutil.validate("12:59 hm")
False
>>> timeutil.validate("2:900 p.m.")
False
>>> timeutil.validate("25:66 a.m.")
False

"""

import doctest
doctest.testmod(verbose = True)