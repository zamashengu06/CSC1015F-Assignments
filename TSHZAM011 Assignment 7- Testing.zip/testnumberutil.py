# Doctest to develop a set of 8 test cases that achieve path coverage
# Zamashengu Tshabalala
# TSHZAM011
# 9 April 2024

"""
>>> import numberutil
>>> numberutil.aswords(999)
'nine hundred and ninety nine'
>>> numberutil.aswords(300)
'three hundred'
>>> numberutil.aswords(808)
'eight hundred and eight'
>>> numberutil.aswords(490)
'four hundred and ninety'
>>> numberutil.aswords(21)
'twenty one'
>>> numberutil.aswords(15)
'fifteen'
>>> numberutil.aswords(50)
'fifty'
>>> numberutil.aswords(0)
'zero'

 """

import doctest
doctest.testmod(verbose = True)