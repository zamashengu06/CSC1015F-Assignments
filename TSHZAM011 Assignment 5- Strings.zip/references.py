# Program to reformat references to be consistent
# Zamashengu Tshabalala TSHZAM011
# 21 March 2024

ref = input("Enter the reference:\n")

org_occ = ref.find(",")
sec_occ = ref.find(",", org_occ + 1) 



end_n = ref.find("(")
start_t = ref.find("(") + 7

year = ref[end_n: start_t]

authors =  ref[:end_n]
author_name = authors.title()

title = ref[start_t: sec_occ + 1]
title2 = title.capitalize()

rest = ref[sec_occ + 1:]
print("Reformatted reference: ")
print(author_name + year  + title2 + rest)


