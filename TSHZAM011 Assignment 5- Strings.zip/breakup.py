# Program ’ that accepts a sentence as input and that outputs it as comma separated words
# Zamashengu Tshabalala TSHZAM011
# 21 March 2024

lists = input("Enter a sentence:\n")
new = lists.lower()

nenw = ""
for i in new:
      if i == " ":
            i = ", "
            nenw = nenw + i     
      else: 
            nenw = nenw + i  
print("The word list: " + nenw, end = ". ")




