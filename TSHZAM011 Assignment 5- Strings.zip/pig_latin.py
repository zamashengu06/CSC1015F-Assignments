# Program to convert Python english to Pig latin
# Zamashengu Tshabalala TSHZAM011
# 23 March 2024

sentence = input("Enter a sentence:\n") + " "
sen = sentence.lower()

vow = "aeiou"
new = ""
output = ""
for i in sen:
   if i != " ":
         new = new + i     
   else: 
         first = new[0]
         vowel = False
            
         for d in range(len(vow)):
            if first == vow[d]:
               vowel = True
               break
                  
         if vowel:
            output = output + new + "way "
         else:
            cons = ""
            for x in new:
               consonant = True
               for c in range(len(vow)):
                  if x == vow[c]:
                     consonant = False
                     break
               if consonant:
                  cons = cons + x
               else:
                  break
                        
            output = output + new[len(cons):] + "a" + cons + "ay "
   
         new = ""    

print(output)
      
                  
       




