# Program to transform 24-hour format to 12-hour format
# Zamashengu Tshabalala TSHZAM011
# 21 March 2024

date = input("Enter the date and time (yyyy-mm-dd hh:mm):\n")


time = date[11:13]
minu = date[13:16]
year = date[2:4]

if int(time) > 12:
    time2 =  str(int(time) - 12) + minu + " pm on the "
elif int(time) == 12:
    time2 = str(int(time)) + minu + " pm on the "
elif int(time) == 0:
    time2 = str(int(time) + 12) + minu + " am on the "

else:
    time2 = str(int(time)) + minu + " am on the "

month = date[5:7]

if int(month) == 1:
    month2 = "January"
elif int(month) == 2:
    month2 = "February"
elif int(month) == 3:
    month2 = "March"
elif int(month) == 4:
    month2 = "April"
elif int(month) == 5:
    month2 = "May"
elif int(month) == 6:
    month2 = "June"
elif int(month) == 7:
    month2 = "July"
elif int(month) == 8:
    month2 = "August"
elif int(month) == 9:
    month2 = "September"
elif int(month) == 10:
    month2 = "October"
elif int(month) == 11:
    month2 = "November"
elif int(month) == 12:
    month2 = "December"

org_num = date[8:9]
day = date[9:10]




if int(day) >= 4 or int(day) == 0:
    day_suff = str(int(day)) + "th"
elif int(day) == 3  and (int(org_num) >= 2 or int(org_num) ==0):
    day_suff = str(int(day)) + "rd"
elif int(day) == 2 and int(org_num) >= 2:
    day_suff = str(int(day))+ "nd"
elif int(day) == 1 and int(org_num) >= 2:
    day_suff = str(int(day))+ "st"
elif int(org_num) == 1 and int(day)<=4:
        day_suff = str(int(day)) + "th"
elif int(day) == 1 and int(org_num) == 0:
    day_suff = str(int(day)) + "st"
elif int(day) == 2 and int(org_num) == 0:
    day_suff = str(int(day)) + "nd"



if int(org_num) == 0:
    print(time2 + day_suff+ " of " + month2 + " '" +year)
else:
    print(time2 + date[8:9]+ day_suff + " of " + month2 + " '" + year )




    